package main

type department interface {
	getNumberOfProfessors() int
	getName() string
}
