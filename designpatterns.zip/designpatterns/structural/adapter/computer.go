package main

type computer interface {
	insertInSquarePort()
}
