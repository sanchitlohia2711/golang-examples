package main

type sportsKit interface {
	clone() sportsKit
}
