package main

type nikeShort struct {
	short
}
