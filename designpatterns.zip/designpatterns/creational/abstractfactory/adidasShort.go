package main

type adidasShort struct {
	short
}
